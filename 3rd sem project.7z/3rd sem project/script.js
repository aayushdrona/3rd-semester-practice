window.addEventListener('resize', function() {
    var button = document.getElementById('myButton');
    if (window.innerWidth <= 1196) {
      button.style.display = 'block';
      button.style.backgroundColor = 'white';
      button.style.color = 'black';
    } else {
      button.style.display = 'none';
    }
  });

  const button = document.getElementById('shakeButton');

button.addEventListener('mouseenter', () => {
  button.style.animation = 'shake 0.4s';
});

button.addEventListener('mouseleave', () => {
  button.style.animation = '';
});


  